 
 //variable declaration section
 let physicsWorld, scene, camera, renderer, rigidBodies = [], tmpTrans = null, stars, clock
 let moveDirection = { left: 0, right: 0, forward: 0, back: 0 }
 var controls,cbContactPairResult; 
 var ammoTmpPos;
 var ammoTmpQuat;
 var spikeyTotem;
 var coins = [];
 var spikeyTotems = [];
 var slipperySurface = [];
 var platforms = [];
 var clouds = [];
 var player;
 var SlipperyPlane;
 var blockPlane;
 var cloud_group;
 let scalingFactor = 15;
 var heart;
 var heart_lives = [];
 var jump_height = 12;
 var paused = false;
 var skyStars = [];
 var starPoints;
 var portalParticles = [];
 var smokeParticles = [];
 var portal_group;
 var portalAlt;
 var cars = [];
 var max_height = 17;

// initialise score variable;
var playerScore = 0;
var lives = 3;

const STATE = { DISABLE_DEACTIVATION : 4 }
const FLAGS = { CF_KINEMATIC_OBJECT: 2 };
// Getting html elements
const score = document.getElementById("score");
const menu = document.getElementById("mainMenu");
const fuel = document.getElementById("jumpFuel");
const levels = document.getElementById("levels");
const settings = document.getElementById("settings");
const credits = document.getElementById("credits");
const Playerlives = document.getElementById("lives");
const interface1 = document.getElementById("interface");
const PauseButton = document.getElementById("pauseButton");


function PauseButtonToggle(){
    if(document.getElementById("pauseButton").className == "pause")
       document.getElementById("pauseButton").className = "resume";
    else
       document.getElementById("pauseButton").className = "pause";
}

function start (){
    tmpTrans = new Ammo.btTransform(); 
    ammoTmpPos = new Ammo.btVector3();
    ammoTmpQuat = new Ammo.btQuaternion();  
    setupPhysicsWorld();
    setupGraphics();
    
    // Display player score
    score.innerHTML = playerScore;

    // Display player lives
    Playerlives.innerHTML = lives;
    
    createBackground();

    pos_clouds = [
        {x: -10, y: 50, z:-50},
        {x: -5, y: 35, z:-30}
    ];

    createClouds(pos_clouds,{x: 5, y: 5, z: 5});

    pos_platforms = [
        {x: 0, y: 0, z: 0},
        {x: 0, y: 0, z:-200}
    ];
    createBlock(pos_platforms,{x: 100, y: 2, z: 100});

    pos_slippery = [
        {x: 0, y: 0, z:-100}
    ];
    createSlippery(pos_slippery,{x: 100, y: 2, z: 100});

    createTree({x: -30, y: 0, z: 2});
    createTree({x: 30, y: 0, z: 2});
    createTree({x: -30, y: 0, z: 40});
    createTree({x: 30, y: 0, z: 40});
    createTree({x: -30, y: 0, z: -200});
    createTree({x: 30, y: 0, z: -200});
     
    pos_coin = [
        {x: 0, y: 5, z: -10},
        {x: 0, y: 5, z: -5},
        {x: 0, y: 5, z: -21}
    ];
    createCoins(pos_coin);

    pos_totem = [
        {x: 0, y: 5, z: -30},
        {x: 15, y: 5, z: -20},
        {x: -10, y: 5, z: -15}
    ];
    createSpikeyTotem(pos_totem);
    
    pos_hearts = [
        {x: 0, y: 5, z: -5}
    ];
    createLives(pos_hearts);

    createPlayer();
    //createSnowman();
    pos_cars = [
        {x: 5, y: 5, z: -50}
        // {x: 0, y: 5, z: -65},
        // {x: -5, y: 5, z: -88}
     ];
    createCar(pos_cars,{x: 0.5, y: 0.5, z: 0.5});
    setupContactPairResultCallback();
    setupEventHandlers();
    renderFrame();


}

function setupPhysicsWorld(){

     let collisionConfiguration  = new Ammo.btDefaultCollisionConfiguration(),
         dispatcher              = new Ammo.btCollisionDispatcher(collisionConfiguration),
         overlappingPairCache    = new Ammo.btDbvtBroadphase(),
         solver                  = new Ammo.btSequentialImpulseConstraintSolver();

     physicsWorld           = new Ammo.btDiscreteDynamicsWorld(dispatcher, overlappingPairCache, solver, collisionConfiguration);
     physicsWorld.setGravity(new Ammo.btVector3(0, -20, 0));

}

function setupGraphics(){
    tmpTrans = new Ammo.btTransform(); 
    ammoTmpPos = new Ammo.btVector3();
    ammoTmpQuat = new Ammo.btQuaternion();  
    // Display player score
    score.innerHTML = playerScore;

    // Display player lives
    Playerlives.innerHTML = lives;
     //create clock for timing
     clock = new THREE.Clock();

     //create the scene
     scene = new THREE.Scene();
     scene.background = new THREE.Color( 0x2e70db);//bfd1e5 );

     //create camera
     camera = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 0.2, 5000 );
     camera.position.set( 0, 30, 100 );
     camera.rotation.x = Math.PI/2;
     camera.lookAt(new THREE.Vector3(0, 0, 0)); // interferes with portal

     //Add hemisphere light
     let hemiLight = new THREE.HemisphereLight( 0xffffff, 0xffffff, 0.1 );
     hemiLight.color.setHSL( 0.6, 0.6, 0.6 );
     hemiLight.groundColor.setHSL( 0.1, 1, 0.4 );
     hemiLight.position.set( 0, 50, 0 );
     scene.add( hemiLight );

     //Add directional light
     let dirLight = new THREE.DirectionalLight( 0xffffff , 1);
     dirLight.color.setHSL( 0.1, 1, 0.95 );
     dirLight.position.set( -1, 1.75, 1 );
     dirLight.position.multiplyScalar( 100 );
     scene.add( dirLight );

     dirLight.castShadow = true;

     dirLight.shadow.mapSize.width = 2048;
     dirLight.shadow.mapSize.height = 2048;

     let d = 50;

     dirLight.shadow.camera.left = -d;
     dirLight.shadow.camera.right = d;
     dirLight.shadow.camera.top = d;
     dirLight.shadow.camera.bottom = -d;

     dirLight.shadow.camera.far = 13500;

     //Setup the renderer
     renderer = new THREE.WebGLRenderer( { antialias: true } );
     renderer.setClearColor( 0xbfd1e5 );
     renderer.setPixelRatio( window.devicePixelRatio );
     renderer.setSize( window.innerWidth, window.innerHeight );
     document.body.appendChild( renderer.domElement );

     renderer.gammaInput = true;
     renderer.gammaOutput = true;

     renderer.shadowMap.enabled = true;


}

function renderFrame(){
    
        if(paused == false){
            let deltaTime = clock.getDelta();
            for(var h = 0; h < clouds.length; ++h){
            clouds[h].position.x += 0.02;
            }
            
            movePlayer();
            if(player != undefined){
                //check if player fell off platform
                checkPlayerDead();
            }
        
    
            for(var j = 0; j < coins.length; ++j){
            coins[j].rotation.z += 0.05;
            
            }
            contactCoin();
            
            for(var k = 0; k < spikeyTotems.length; ++k){
            spikeyTotems[k].rotation.y += 0.05;
            }
            
            contactSpike();
            contactSlippery();
            contactPlatform();
            
            for(var n = 0; n < heart_lives.length; ++n){
            heart_lives[n].rotation.y += 0.02;
            }
            contactHearts();

            contactCar();
            
            //background
            skyStars.forEach(p => {
                p.velocity += p.acceleration
                p.y -= p.velocity;
                
                if (p.y < -200) {
                p.y = 200;
                p.velocity = 0;
                }
            });
            //starGeo.verticesNeedUpdate = true;
            stars.rotation.y +=0.002;

            //portal
            portalParticles.forEach(p => {
                p.rotation.z -= deltaTime *1.5;
            });
            smokeParticles.forEach(p => {
                p.rotation.z -= deltaTime *0.2;
            });
            if(Math.random() > 0.9) {
                //portalLight.power =350 + Math.random()*500;
            }

            //animates portal
            if(playerScore == 30){
            portalAlt.rotation.z +=0.05;
            contactPortal();
            }
            updatePhysics( deltaTime );
            renderer.render( scene, camera );
            requestAnimationFrame( renderFrame );
    
        }
}

function setupEventHandlers(){

    window.addEventListener( 'keydown', handleKeyDown, false);
    window.addEventListener( 'keyup', handleKeyUp, false); 
}


function handleKeyDown(event){

    let keyCode = event.keyCode;

    switch(keyCode){

        case 87: //W: FORWARD
            moveDirection.forward = 1;
            break;
             
        case 83: //S: BACK
            moveDirection.back = 1
            break;
             
        case 65: //A: LEFT
            moveDirection.left = 1
            break;
             
        case 68: //D: RIGHT
            moveDirection.right = 1
            break;
        
        case 74://J
            jump();
            jump_height = jump_height + 0.5;
            break;
        
        case 38: //↑: FORWARD
            kMoveDirection.forward = 1
            break;
             
        case 40: //↓: BACK
            kMoveDirection.back = 1
            break;
             
        case 37: //←: LEFT
            kMoveDirection.left = 1
            break;
             
        case 39: //→: RIGHT
            kMoveDirection.right = 1
            break;                                 
    }
}


function handleKeyUp(event){
    let keyCode = event.keyCode;

    switch(keyCode){
        case 87: //FORWARD
            moveDirection.forward = 0
            break;
             
        case 83: //BACK
            moveDirection.back = 0
            break;
             
        case 65: //LEFT
            moveDirection.left = 0
            break;
             
        case 68: //RIGHT
            moveDirection.right = 0
            break;
        
        case 74://J
            //jump();
            max_height = max_height + 1;
            break;
        
        case 38: //↑: FORWARD
            kMoveDirection.forward = 0
            break;
             
        case 40: //↓: BACK
            kMoveDirection.back = 0
            break;
             
        case 37: //←: LEFT
            kMoveDirection.left = 0
            break;
             
        case 39: //→: RIGHT
            kMoveDirection.right = 0
            break;              
    }
} 

function updatePhysics( deltaTime ){
    camera.position.copy(player.position).add(new THREE.Vector3(0, 25, 35));
     // Step world
     physicsWorld.stepSimulation( deltaTime, 10 );

     // Update rigid bodies
     for ( let i = 0; i < rigidBodies.length; i++ ) {
         let objThree = rigidBodies[ i ];
         let objAmmo = objThree.userData.physicsBody;
         let ms = objAmmo.getMotionState();
         if ( ms ) {

             ms.getWorldTransform( tmpTrans );
             let p = tmpTrans.getOrigin();
             let q = tmpTrans.getRotation();
             objThree.position.set( p.x(), p.y(), p.z() );
             objThree.quaternion.set( q.x(), q.y(), q.z(), q.w() );

         }
     }
}

//Pause function
function togglePause(){

    if (!paused){
        PauseButtonToggle()
        paused = true;
    } 
    else if (paused){
        PauseButtonToggle()
       paused= false;
       renderFrame();
    }
}

//scene background
function createBackground(){

    for(let i=0;i<6000;i++) {
      var star = new THREE.Vector3(
        Math.random() * 600 - 300,
        Math.random() * 600 - 300,
        Math.random() * 600 - 300
      );
      star.velocity = 0;
      star.acceleration = 0.02;
      skyStars.push(star);
    }

    let texture = new THREE.TextureLoader().load( 'Images/star.png' );
    let starMaterial = new THREE.PointsMaterial({
      color: 0xaaaaaa,
      size: 0.7,
      map: texture
    });

    starPoints = new THREE.BufferGeometry().setFromPoints( skyStars );
    stars = new THREE.Points(starPoints,starMaterial);
    scene.add(stars); 
}

function createSlippery(pos,scale){
    //let pos = {x: 0, y: 0, z: 0};
    //let scale = {x: 100, y: 2, z: 100};
    let quat = {x: 0, y: 0, z: 0, w: 1};
    let mass = 0;

    var texture = new THREE.TextureLoader().load( "Images/ice.jpg" );
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set( 4, 4 );

    for(var i = 0; i < pos.length; ++i){
        //threeJS Section
    
        SlipperyPlane = new THREE.Mesh(new THREE.BoxGeometry(), new THREE.MeshPhongMaterial({map: texture, shininess: 100,specular: 0x050505}));
        SlipperyPlane.name = "slippery_platform";
        SlipperyPlane.position.set(pos[i].x, pos[i].y, pos[i].z);
        SlipperyPlane.scale.set(scale.x, scale.y, scale.z);

        SlipperyPlane.castShadow = true;
        SlipperyPlane.receiveShadow = true;

        scene.add(SlipperyPlane);

        //Ammojs Section
        let transform = new Ammo.btTransform();
        transform.setIdentity();
        transform.setOrigin( new Ammo.btVector3( pos[i].x, pos[i].y, pos[i].z ) );
        transform.setRotation( new Ammo.btQuaternion( quat.x, quat.y, quat.z, quat.w ) );
        let motionState = new Ammo.btDefaultMotionState( transform );

        let colShape = new Ammo.btBoxShape( new Ammo.btVector3( scale.x * 0.5, scale.y * 0.5, scale.z * 0.5 ) );
        colShape.setMargin( 0.05 );

        let localInertia = new Ammo.btVector3( 0, 0, 0 );
        colShape.calculateLocalInertia( mass, localInertia );

        let rbInfo = new Ammo.btRigidBodyConstructionInfo( mass, motionState, colShape, localInertia );
        let body = new Ammo.btRigidBody( rbInfo );

        body.setFriction(4);
        body.setRollingFriction(10);

        physicsWorld.addRigidBody( body );
        SlipperyPlane.userData.physicsBody = body;
        slipperySurface.push(SlipperyPlane);
        //console.log(scalingFactor);
    }
}

 function contactSlippery(){
    //console.log(slipperySurface);
   for(var k = 0; k < slipperySurface.length; ++k){
       cbContactPairResult.hasContact = false;
       physicsWorld.contactPairTest(player.userData.physicsBody, slipperySurface[k].userData.physicsBody, cbContactPairResult);

       if(cbContactPairResult.hasContact){
           //increase speed of ball
           scalingFactor = 25;  
       }
   }
}

function createBlock(pos,scale){
     
    //  let pos = {x: 0, y: 0, z: 0};
     //let scale = {x: 100, y: 2, z: 100};
     let quat = {x: 0, y: 0, z: 0, w: 1};
     let mass = 0;

    //texture
    var texture = new THREE.TextureLoader().load( "Images/grass_texture.png" );
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set( 4, 4 );

    for(var i = 0; i < pos.length; ++i){
        //threeJS Section
    
        blockPlane = new THREE.Mesh(new THREE.BoxBufferGeometry(), new THREE.MeshPhongMaterial({map: texture}));
        blockPlane.name = "block";
        blockPlane.position.set(pos[i].x, pos[i].y, pos[i].z);
        blockPlane.scale.set(scale.x, scale.y, scale.z);

        blockPlane.castShadow = true;
        blockPlane.receiveShadow = true;

        scene.add(blockPlane);


        //Ammojs Section
        let transform = new Ammo.btTransform();
        transform.setIdentity();
        transform.setOrigin( new Ammo.btVector3( pos[i].x, pos[i].y, pos[i].z ) );
        transform.setRotation( new Ammo.btQuaternion( quat.x, quat.y, quat.z, quat.w ) );
        let motionState = new Ammo.btDefaultMotionState( transform );

        let colShape = new Ammo.btBoxShape( new Ammo.btVector3( scale.x * 0.5, scale.y * 0.5, scale.z * 0.5 ) );
        colShape.setMargin( 0.05 );

        let localInertia = new Ammo.btVector3( 0, 0, 0 );
        colShape.calculateLocalInertia( mass, localInertia );

        let rbInfo = new Ammo.btRigidBodyConstructionInfo( mass, motionState, colShape, localInertia );
        let body = new Ammo.btRigidBody( rbInfo );

        body.setFriction(4);
        body.setRollingFriction(10);

        physicsWorld.addRigidBody( body );
        blockPlane.userData.physicsBody = body;
        platforms.push(blockPlane);
    }
}

 function contactPlatform(){
    for(var k = 0; k < platforms.length; ++k){
        cbContactPairResult.hasContact = false;
        physicsWorld.contactPairTest(player.userData.physicsBody, platforms[k].userData.physicsBody, cbContactPairResult);

        if(cbContactPairResult.hasContact){
            //increase speed of ball
            scalingFactor = 15;   
        }
    }
}


function createPlayer(){
    let pos = {x: 0, y: 4, z: 0};
    let radius = 2;
    let quat = {x: 0, y: 0, z: 0, w: 1};
    let mass = 60;

    //threeJS Section
    let ball = player = new THREE.Mesh(new THREE.SphereBufferGeometry(radius), new THREE.MeshPhongMaterial({color: 0xff0505}));
    player.name = "ball";
    player.position.set(pos.x, pos.y, pos.z);
    
    player.castShadow = true;
    player.receiveShadow = true;

    scene.add(ball);


    //Ammojs Section
    let transform = new Ammo.btTransform();
    transform.setIdentity();
    transform.setOrigin( new Ammo.btVector3( pos.x, pos.y, pos.z ) );
    transform.setRotation( new Ammo.btQuaternion( quat.x, quat.y, quat.z, quat.w ) );
    let motionState = new Ammo.btDefaultMotionState( transform );

    let colShape = new Ammo.btSphereShape( radius );
    colShape.setMargin( 0.5 );

    let localInertia = new Ammo.btVector3( 5, 5, 5 );
    colShape.calculateLocalInertia( mass, localInertia );

    let rbInfo = new Ammo.btRigidBodyConstructionInfo( mass, motionState, colShape, localInertia );
    let body = new Ammo.btRigidBody( rbInfo );

    body.setFriction(4);
    body.setRollingFriction(4);

    body.setActivationState( STATE.DISABLE_DEACTIVATION )


    physicsWorld.addRigidBody( body );
    
    player.userData.physicsBody = body;
    rigidBodies.push(player);

    player.userData.physicsBody = body;
               
    body.threeObject = player;

}

function jump(){
    // if(jump_height > max_height){
    //     jump_height = max_height;
    // }
    // var new_player_height = player.position.y + jump_height;
    // console.log("new height",Math.abs(player.position.y - new_player_height));
    // console.log("player height",Math.abs(player.position.y));
    // if(player.position.y <= Math.abs(player.position.y - new_player_height)){
        
    //     let jumpImpulse = new Ammo.btVector3( 0, jump_height, 0 );
    
    //     let physicsBody = player.userData.physicsBody;
    //     physicsBody.setLinearVelocity( jumpImpulse );
    //     //reset
    //     onGround = false; 
    //     jump_height = 12;
    // } 

    if(player.position.y >= 0 && player.position.y <= 10){
        if(jump_height > 17){
            jump_height = 17;
        }
    
        let jumpImpulse = new Ammo.btVector3( 0, jump_height, 0 );
    
        let physicsBody = player.userData.physicsBody;
        physicsBody.setLinearVelocity( jumpImpulse );
        //reset
        jump_height = 12;
    }
}

function movePlayer(){
    let moveX =  moveDirection.right - moveDirection.left;
     let moveZ =  moveDirection.back - moveDirection.forward;
     let moveY =  0; 

     if( moveX == 0 && moveY == 0 && moveZ == 0) return;

     let resultantImpulse = new Ammo.btVector3( moveX, moveY, moveZ )
     resultantImpulse.op_mul(scalingFactor);

     let physicsBody = player.userData.physicsBody;
     physicsBody.setLinearVelocity( resultantImpulse );

}

function checkPlayerDead(){
    if(player.position.y < -1  && player.visible == true){
        console.log("you are dead!");
        player.visible = false;
        location.replace("test.html");
    }
}

function createLives(pos){
    const shape = new THREE.Shape();
    const x = -2.5;
    const y = -5;
    shape.moveTo(x + 2.5, y + 2.5);
    shape.bezierCurveTo(x + 2.5, y + 2.5, x + 2, y, x, y);
    shape.bezierCurveTo(x - 3, y, x - 3, y + 3.5, x - 3, y + 3.5);
    shape.bezierCurveTo(x - 3, y + 5.5, x - 1.5, y + 7.7, x + 2.5, y + 9.5);
    shape.bezierCurveTo(x + 6, y + 7.7, x + 8, y + 4.5, x + 8, y + 3.5);
    shape.bezierCurveTo(x + 8, y + 3.5, x + 8, y, x + 5, y);
    shape.bezierCurveTo(x + 3.5, y, x + 2.5, y + 2.5, x + 2.5, y + 2.5);


    const extrudeSettings = {
        steps: 2,  
        depth: 1,  
        bevelEnabled: true,  
        bevelThickness: 0.27,  
        bevelSize: 0.19,  
        bevelSegments: 2,  
    };


    //let pos = {x: 0, y: 10, z: 0};
    let scale = {x: 0.3, y: -0.3, z: 0.3};
    let quat = {x: 0, y: 0, z: 0, w: 1};
    let mass = 0;


    for(var i = 0; i < pos.length; ++i){
        const geometry = new THREE.ExtrudeGeometry( shape, extrudeSettings );
        const material = new THREE.MeshPhongMaterial( { color: 0xFF0000 } );
        heart = new THREE.Mesh( geometry, material ) ;
        heart.scale.set(scale.x,scale.y,scale.z);
        heart.position.set(pos[i].x,pos[i].y,pos[i].z);
        scene.add( heart );


        //Ammojs Section
        let transform = new Ammo.btTransform();
        transform.setIdentity();
        transform.setOrigin( new Ammo.btVector3( pos[i].x, pos[i].y, pos[i].z ) );
        transform.setRotation( new Ammo.btQuaternion( quat.x, quat.y, quat.z, quat.w ) );
        let motionState = new Ammo.btDefaultMotionState( transform );
    
        let colShape = new Ammo.btBoxShape( new Ammo.btVector3( scale.x * 0.5, scale.y * 0.5, scale.z * 0.5 ) );
        colShape.setMargin( 0.05 );
    
        let localInertia = new Ammo.btVector3( 0, 0, 0 );
        colShape.calculateLocalInertia( mass, localInertia );
    
        let rbInfo = new Ammo.btRigidBodyConstructionInfo( mass, motionState, colShape, localInertia );
        let body = new Ammo.btRigidBody( rbInfo );
    
        body.setFriction(4);
        body.setRollingFriction(10);
    
        body.setActivationState( STATE.DISABLE_DEACTIVATION );
        body.setCollisionFlags( FLAGS.CF_KINEMATIC_OBJECT );
    
    
        physicsWorld.addRigidBody( body );
        heart.userData.physicsBody = body;
        heart_lives.push(heart);
    }

}

function contactHearts(){
    for(var k = 0; k < heart_lives.length; ++k){
        cbContactPairResult.hasContact = false;
        physicsWorld.contactPairTest(player.userData.physicsBody, heart_lives[k].userData.physicsBody, cbContactPairResult);

        if(cbContactPairResult.hasContact && heart_lives[k].visible == true){
            heart_lives[k].visible = false;
            heart_lives[k].userData.dead = true;
            physicsWorld.removeRigidBody( heart_lives[k].userData.physicsBody );
            ++lives; 
            Playerlives.innerHTML = lives;
        }
    }
 }

function createCoins(pos){
     //let pos = {x: 0, y: 8, z: 7};
     let scale = {x: 2, y: 10, z: 2};
     let quat = {x: 0, y: 0, z: 0, w: 1};
     let mass = 0;
 
     var texture = new THREE.TextureLoader().load( "Images/coins.jpg" );
     texture.wrapS = THREE.RepeatWrapping;
     texture.wrapT = THREE.RepeatWrapping;
     texture.repeat.set( 4, 4 );

     for(var i = 0; i < pos.length; ++i){
         //console.log(pos[i]);
         var coin = new THREE.Mesh(new THREE.CylinderGeometry( 1, 1, 0.05,18), new THREE.MeshPhongMaterial({color: 0xffff00, map:texture, shininess:0.5}));
         coin.name = "coin";
         coin.position.set(pos[i].x,pos[i].y,pos[i].z);
         coin.scale.set(scale.x,scale.y,scale.z);
         coin.rotation.set(1,0,0);
 
         coin.castShadow = true;
         coin.receiveShadow = true;
 
         scene.add(coin);
 
         //Ammojs Section
         let transform = new Ammo.btTransform();
         transform.setIdentity();
         transform.setOrigin( new Ammo.btVector3( pos[i].x, pos[i].y, pos[i].z ) );
         transform.setRotation( new Ammo.btQuaternion( quat.x, quat.y, quat.z, quat.w ) );
         let motionState = new Ammo.btDefaultMotionState( transform );
     
         let colShape = new Ammo.btBoxShape( new Ammo.btVector3( scale.x * 0.5, scale.y * 0.5, scale.z * 0.5 ) );
         colShape.setMargin( 0.05 );
     
         let localInertia = new Ammo.btVector3( 0, 0, 0 );
         colShape.calculateLocalInertia( mass, localInertia );
     
         let rbInfo = new Ammo.btRigidBodyConstructionInfo( mass, motionState, colShape, localInertia );
         let body = new Ammo.btRigidBody( rbInfo );
     
         body.setFriction(4);
         body.setRollingFriction(10);
     
         body.setActivationState( STATE.DISABLE_DEACTIVATION );
         body.setCollisionFlags( FLAGS.CF_KINEMATIC_OBJECT );
     
         physicsWorld.addRigidBody( body );
         coin.userData.physicsBody = body;
         coins.push(coin);
     }
}

function contactCoin(){
    for(var k = 0; k < coins.length; ++k){
        cbContactPairResult.hasContact = false;
        physicsWorld.contactPairTest(player.userData.physicsBody, coins[k].userData.physicsBody, cbContactPairResult);

        if(cbContactPairResult.hasContact && coins[k].visible == true){
            coins[k].visible = false;
            coins[k].userData.dead = true;
            physicsWorld.removeRigidBody( coins[k].userData.physicsBody );
            ++playerScore;
            score.innerHTML = playerScore;
            
            if(playerScore == 30){
               // createPortal();
                createAltPortal();
            }
        }
    }
    
}

function createSpikeyTotem(pos){
    //let pos = {x: 0, y: 5, z: -27};
    let scale = {x: 2, y: 10, z: 2};
    let quat = {x: 0, y: 0, z: 0, w: 1};
    let mass = 0;
    var texture = new THREE.TextureLoader().load( "Images/bark.jpg" );
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set( 4, 4 );
    for(var i = 0; i < pos.length; ++i){
        //threeJS Section
        var spikeyTotem = new THREE.Group();
        spikeyTotem.position.set(pos[i].x,pos[i].y,pos[i].z);
        var totem = new THREE.Mesh(new THREE.CylinderGeometry(), new THREE.MeshLambertMaterial({map:texture}));
        //totem.position.set(pos.x,pos.y,pos.z);
        totem.scale.set(scale.x,scale.y,scale.z);
        totem.castShadow = true;
        totem.receiveShadow = true;
        spikeyTotem.add(totem);

        var spikes = new THREE.Mesh(new THREE.ConeGeometry(0.5, 1), new THREE.MeshPhongMaterial({color: 0xd6d6c2, shininess: 0.5}));
        spikes.position.set(pos[i].x,pos[i].y,pos[i].z);
        spikes.scale.set(scale.x/2,scale.y/2,scale.z/2);
        spikes.rotation.set(0,0,0);
        spikes.castShadow = true;
        spikes.receiveShadow = true;
        //spikeyTotem.add(spikes);

        var spikes1 = spikes.clone();
        spikes1.position.set(0,4,3);
        //spikes1.position.set(pos.x,pos.y-1,pos.z+8);
        spikes1.rotation.set(1,0,0);
        spikeyTotem.add(spikes1);

        var spikes2 = spikes.clone();
        spikes2.position.set(0,0.5,3);
        //spikes2.position.set(pos.x,pos.y-4.5,pos.z+8);
        spikes2.rotation.set(1,0,0);
        spikeyTotem.add(spikes2);

        var spikes3 = spikes.clone();
        spikes3.position.set(3,0,0);
        //spikes3.position.set(pos.x+3,pos.y-pos.y,pos.z-pos.z);
        spikes3.rotation.set(0,0,-1);
        spikeyTotem.add(spikes3);

        var spikes4 = spikes.clone();
        spikes4.position.set(-3,0,0);
        //spikes4.position.set(pos.x-3,pos.y-pos.y,pos.z-pos.z);
        spikes4.rotation.set(0,0,1);
        spikeyTotem.add(spikes4);

        var spikes5 = spikes.clone();
        spikes5.position.set(0,4,-3);
        // spikes5.position.set(pos.x,pos.y-1,pos.z+2);
        spikes5.rotation.set(-1,0,0);
        spikeyTotem.add(spikes5);

        var spikes6 = spikes.clone();
        spikes6.position.set(0,0.5,-3);
        // spikes6.position.set(pos.x,pos.y-4.5,pos.z+2);
        spikes6.rotation.set(-1,0,0);
        spikeyTotem.add(spikes6);


        scene.add(spikeyTotem);

        //Ammojs Section
        let transform = new Ammo.btTransform();
        transform.setIdentity();
        transform.setOrigin( new Ammo.btVector3( pos[i].x, pos[i].y, pos[i].z ) );
        transform.setRotation( new Ammo.btQuaternion( quat.x, quat.y, quat.z, quat.w ) );
        let motionState = new Ammo.btDefaultMotionState( transform );

        let colShape = new Ammo.btBoxShape( new Ammo.btVector3( scale.x , scale.y , scale.z  ) );
        colShape.setMargin(1 );

        let localInertia = new Ammo.btVector3( 0, 0, 0 );
        colShape.calculateLocalInertia( mass, localInertia );

        let rbInfo = new Ammo.btRigidBodyConstructionInfo( mass, motionState, colShape, localInertia );
        let body = new Ammo.btRigidBody( rbInfo );

        body.setFriction(4);
        body.setRollingFriction(10);

        body.setActivationState( STATE.DISABLE_DEACTIVATION );
        body.setCollisionFlags( FLAGS.CF_KINEMATIC_OBJECT );


        physicsWorld.addRigidBody( body );
        spikeyTotem.userData.physicsBody = body;
        spikeyTotems.push(spikeyTotem);
    }
}

function contactSpike(){
     
    for(var k = 0; k < spikeyTotems.length; ++k){
        cbContactPairResult.hasContact = false;
        physicsWorld.contactPairTest(player.userData.physicsBody, spikeyTotems[k].userData.physicsBody, cbContactPairResult);

        if(cbContactPairResult.hasContact && spikeyTotems[k].visible == true && lives > 0){
            spikeyTotems[k].visible = false;
            spikeyTotems[k].userData.dead = true;
            physicsWorld.removeRigidBody( spikeyTotems[k].userData.physicsBody );
            --lives;
            Playerlives.innerHTML = lives;

            if(lives == 0){
                console.log("dead!");
                 player.visible = false;
                 player.userData.dead = true;
                 physicsWorld.removeRigidBody( player.userData.physicsBody );
                location.replace("test.html");
            }
        }
    }
}


function createAltPortal(){

     let pos = {x: 0, y: 10, z: -50};
     let scale = {x: 5, y: 5, z: 5};
     let radius = 2;
     let quat = {x: 0, y: 0, z: 0, w: 1};
     let mass = 60;

     var texture = new THREE.TextureLoader().load( "Images/spiral.jpg" );
     texture.wrapS = THREE.ClampToEdgeWrapping;
     texture.wrapT = THREE.ClampToEdgeWrapping;
     //texture.repeat.set( 4, 4 );

     //threeJS Section
     portalAlt = new THREE.Mesh(new THREE.CircleBufferGeometry(radius,100), new THREE.MeshPhongMaterial({map: texture}));
     
     portalAlt.position.set(pos.x, pos.y, pos.z);
     portalAlt.scale.set(scale.x, scale.y, scale.z);

     portalAlt.castShadow = true;
     portalAlt.receiveShadow = true;

     scene.add(portalAlt);
    
     //Ammojs Section
    let transform = new Ammo.btTransform();
    transform.setIdentity();
    transform.setOrigin( new Ammo.btVector3( pos.x, pos.y, pos.z ) );
    transform.setRotation( new Ammo.btQuaternion( quat.x, quat.y, quat.z, quat.w ) );
    let motionState = new Ammo.btDefaultMotionState( transform );

    let colShape = new Ammo.btBoxShape( new Ammo.btVector3( scale.x , scale.y , scale.z  ) );
    colShape.setMargin( 0.05 );

    let localInertia = new Ammo.btVector3( 0, 0, 0 );
    colShape.calculateLocalInertia( mass, localInertia );

    let rbInfo = new Ammo.btRigidBodyConstructionInfo( mass, motionState, colShape, localInertia );
    let body = new Ammo.btRigidBody( rbInfo );

    body.setFriction(4);
    body.setRollingFriction(10);

    body.setActivationState( STATE.DISABLE_DEACTIVATION );
    body.setCollisionFlags( FLAGS.CF_KINEMATIC_OBJECT );


    physicsWorld.addRigidBody( body );
    portalAlt.userData.physicsBody = body;
}

function contactPortal(){
     
        cbContactPairResult.hasContact = false;
        physicsWorld.contactPairTest(player.userData.physicsBody, portalAlt.userData.physicsBody, cbContactPairResult);

        if(cbContactPairResult.hasContact && portalAlt.visible == true){
            portalAlt.visible = false;
            portalAlt.userData.dead = true;
            physicsWorld.removeRigidBody(portalAlt.userData.physicsBody );

            if(playerScore == 3){
                location.replace("test.html");
            }
        }
}

function createTree(pos){
    //let pos = {x: 0, y: 0, z: 5};
    let scale = {x: 2, y: 10, z: 2};
    let quat = {x: 0, y: 0, z: 0, w: 1};
    let mass = 0;

    var texture = new THREE.TextureLoader().load( "Images/bark.jpg" );
     texture.wrapS = THREE.RepeatWrapping;
     texture.wrapT = THREE.RepeatWrapping;
     texture.repeat.set( 4, 4 );

     var texture2 = new THREE.TextureLoader().load( "Images/leaves.jpg" );
     texture2.wrapS = THREE.RepeatWrapping;
     texture2.wrapT = THREE.RepeatWrapping;
     texture2.repeat.set( 4, 4 );

    //threeJS Section
    var tree_group = new THREE.Group();
    tree_group.name = "trees";
    var tree = new THREE.Mesh(new THREE.BoxBufferGeometry(), new THREE.MeshLambertMaterial({map:texture}));
    tree.position.set(pos.x, 10, pos.z);
    tree.scale.set(scale.x, 20, scale.z);

    tree.castShadow = true;
    tree.receiveShadow = true;
    tree_group.add(tree);

    var top = new THREE.Mesh(new THREE.ConeGeometry(3, 1), new THREE.MeshLambertMaterial({color: 0x00ff00, map:texture2}));
    top.position.set(pos.x,30, pos.z);
    top.scale.set(scale.x, scale.y, scale.z);

    top.castShadow = true;
    top.receiveShadow = true;
    tree_group.add(top);

    var mid = new THREE.Mesh(new THREE.ConeGeometry(5, 1), new THREE.MeshLambertMaterial({color: 0x008000, map:texture2}));
    mid.position.set(pos.x,24, pos.z);
    mid.scale.set(scale.x, scale.y, scale.z);

    mid.castShadow = true;
    mid.receiveShadow = true;
    tree_group.add(mid);

    var bottom = new THREE.Mesh(new THREE.ConeGeometry(6, 1), new THREE.MeshLambertMaterial({color: 0x003300, map:texture2}));
    bottom.position.set(pos.x,20, pos.z);
    bottom.scale.set(scale.x, scale.y, scale.z);

    bottom.castShadow = true;
    bottom.receiveShadow = true;
    tree_group.add(bottom);

    scene.add(tree_group);

    //Ammojs Section
    let transform = new Ammo.btTransform();
    transform.setIdentity();
    transform.setOrigin( new Ammo.btVector3( pos.x, pos.y, pos.z ) );
    transform.setRotation( new Ammo.btQuaternion( quat.x, quat.y, quat.z, quat.w ) );
    let motionState = new Ammo.btDefaultMotionState( transform );

    let colShape = new Ammo.btBoxShape( new Ammo.btVector3( scale.x * 0.5, scale.y * 0.5, scale.z * 0.5 ) );
    colShape.setMargin( 0.05 );

    let localInertia = new Ammo.btVector3( 0, 0, 0 );
    colShape.calculateLocalInertia( mass, localInertia );

    let rbInfo = new Ammo.btRigidBodyConstructionInfo( mass, motionState, colShape, localInertia );
    let body = new Ammo.btRigidBody( rbInfo );

    body.setFriction(4);
    body.setRollingFriction(10);

    body.setActivationState( STATE.DISABLE_DEACTIVATION );
    body.setCollisionFlags( FLAGS.CF_KINEMATIC_OBJECT );


    physicsWorld.addRigidBody( body );
    tree_group.userData.physicsBody = body;
    tree.userData.physicsBody = body;
}

function createClouds(pos,scale){
    //let pos = {x: 0, y: 10, z: 0};
    //let scale = {x: 5, y: 5, z: 5};
    let quat = {x: 0, y: 0, z: 0, w: 1};
    let mass = 0;

    for(var i = 0; i < pos.length; ++i){
           //threeJS Section
       cloud_group = new THREE.Group();
       var cloud = new THREE.Mesh(new THREE.SphereGeometry(), new THREE.MeshPhysicalMaterial({color: 0xa6a6a6,clearcoat: 1.0}));
       cloud.position.set(pos[i].x, pos[i].y, pos[i].z);
       cloud.scale.set(scale.x, scale.y, scale.z);

       cloud.castShadow = true;
       cloud.receiveShadow = true;
       cloud_group.add(cloud);

       var cloud_1 = new THREE.Mesh(new THREE.SphereGeometry(), new THREE.MeshPhysicalMaterial({color: 0xcccccc,clearcoat: 1.0}));
       cloud_1.position.set(pos[i].x-7, pos[i].y, pos[i].z);
       cloud_1.scale.set(scale.x, scale.y, scale.z);

       cloud_1.castShadow = true;
       cloud_1.receiveShadow = true;
       cloud_group.add(cloud_1);

       var cloud_2 = new THREE.Mesh(new THREE.SphereGeometry(), new THREE.MeshPhysicalMaterial({color: 0xe6e6e6,clearcoat: 1.0}));
       cloud_2.position.set(pos[i].x+7, pos[i].y, pos[i].z);
       cloud_2.scale.set(scale.x, scale.y, scale.z);

       cloud_2.castShadow = true;
       cloud_2.receiveShadow = true;
       cloud_group.add(cloud_2);

       var cloud_3 = new THREE.Mesh(new THREE.SphereGeometry(), new THREE.MeshPhysicalMaterial({color: 0xffffff,clearcoat: 1.0}));
       cloud_3.position.set(pos[i].x-2.5, pos[i].y+5, pos[i].z);
       cloud_3.scale.set(scale.x, scale.y, scale.z);

       cloud_3.castShadow = true;
       cloud_3.receiveShadow = true;
       cloud_group.add(cloud_3);

       var cloud_4 = new THREE.Mesh(new THREE.SphereGeometry(), new THREE.MeshPhysicalMaterial({color: 0xffffff,clearcoat: 1.0}));
       cloud_4.position.set(pos[i].x+2.5, pos[i].y+5, pos[i].z);
       cloud_4.scale.set(scale.x, scale.y, scale.z);

       cloud_3.castShadow = true;
       cloud_3.receiveShadow = true;
       cloud_group.add(cloud_4);
       
       scene.add(cloud_group);

       //Ammojs Section
       let transform = new Ammo.btTransform();
       transform.setIdentity();
       transform.setOrigin( new Ammo.btVector3( pos[i].x, pos[i].y, pos[i].z ) );
       transform.setRotation( new Ammo.btQuaternion( quat.x, quat.y, quat.z, quat.w ) );
       let motionState = new Ammo.btDefaultMotionState( transform );

       let colShape = new Ammo.btBoxShape( new Ammo.btVector3( scale.x * 0.5, scale.y * 0.5, scale.z * 0.5 ) );
       colShape.setMargin( 0.05 );

       let localInertia = new Ammo.btVector3( 0, 0, 0 );
       colShape.calculateLocalInertia( mass, localInertia );

       let rbInfo = new Ammo.btRigidBodyConstructionInfo( mass, motionState, colShape, localInertia );
       let body = new Ammo.btRigidBody( rbInfo );

       body.setFriction(4);
       body.setRollingFriction(10);

       body.setActivationState( STATE.DISABLE_DEACTIVATION );
       body.setCollisionFlags( FLAGS.CF_KINEMATIC_OBJECT );


       physicsWorld.addRigidBody( body );
       cloud_group.userData.physicsBody = body;
       clouds.push(cloud_group);
    }
}


function contactCar(){
     
    for(var k = 0; k < cars.length; ++k){
        cbContactPairResult.hasContact = false;
        physicsWorld.contactPairTest(player.userData.physicsBody, cars[k].userData.physicsBody, cbContactPairResult);
        if(cbContactPairResult.hasContact && cars[k].visible == true /*&& lives > 0*/){
            cars[k].visible = false;
            cars[k].userData.dead = true;
            physicsWorld.removeRigidBody(cars[k].userData.physicsBody );
            --lives;
            Playerlives.innerHTML = lives;

            if(lives == 0){
                console.log("dead!");
                player.visible = false;
                player.userData.dead = true;
                physicsWorld.removeRigidBody( player.userData.physicsBody );
                location.replace("test.html");
            }
        }    
    }
}

function setupContactPairResultCallback(){

    cbContactPairResult = new Ammo.ConcreteContactResultCallback();
    
    cbContactPairResult.hasContact = false;

    cbContactPairResult.addSingleResult = function(cp, colObj0Wrap, partId0, index0, colObj1Wrap, partId1, index1){
        
        let contactPoint = Ammo.wrapPointer( cp, Ammo.btManifoldPoint );

        const distance = contactPoint.getDistance();

        if( distance > 0 ) return;

        this.hasContact = true;
        
    }

}

//MODEL OF CAR
function pickRandom(array) {
    return array[Math.floor(Math.random() * array.length)];
}

function Wheel() {
    const wheelGeometry = new THREE.BoxBufferGeometry(12, 33, 12);
    const wheelMaterial = new THREE.MeshLambertMaterial({ color: 0x333333 });
    const wheel = new THREE.Mesh(wheelGeometry, wheelMaterial);
    wheel.position.z = 6;
    wheel.castShadow = false;
    wheel.receiveShadow = false;
    return wheel;
}

function getCarFrontTexture() {
    const canvas = document.createElement("canvas");
    canvas.width = 64;
    canvas.height = 32;
    const context = canvas.getContext("2d");
  
    context.fillStyle = "#303030";
    context.fillRect(0, 0, 64, 32);
  
    context.fillStyle = "#666666";
    context.fillRect(8, 8, 48, 24);
  
    return new THREE.CanvasTexture(canvas);
}
  
function getCarSideTexture() {
    const canvas = document.createElement("canvas");
    canvas.width = 128;
    canvas.height = 32;
    const context = canvas.getContext("2d");
  
    context.fillStyle = "#303030";
    context.fillRect(0, 0, 128, 32);
  
    context.fillStyle = "#666666";
    context.fillRect(10, 8, 38, 24);
    context.fillRect(58, 8, 60, 24);
  
    return new THREE.CanvasTexture(canvas);
}
  
function createCar(pos,scale) {
     let quat = {x: 0, y: 0, z: 0, w: 1};
     let mass = 0;
    const vehicleColors = [
        0xa52523,
        0xef2d56,
        0x0ad3ff,
        0xff9f1c /*0xa52523, 0xbdb638, 0x78b14b*/
      ];
    
    for(var i = 0; i < pos.length; ++i){
        const car = new THREE.Group();
  
        const color = pickRandom(vehicleColors);
    
        const main = new THREE.Mesh(
        new THREE.BoxBufferGeometry(60, 30, 15),
        new THREE.MeshLambertMaterial({ color })
        );
        main.position.z = 12;
        main.castShadow = true;
        main.receiveShadow = true;
        car.add(main);
    
        const carFrontTexture = getCarFrontTexture();
        carFrontTexture.center = new THREE.Vector2(0.5, 0.5);
        carFrontTexture.rotation = Math.PI / 2;
    
        const carBackTexture = getCarFrontTexture();
        carBackTexture.center = new THREE.Vector2(0.5, 0.5);
        carBackTexture.rotation = -Math.PI / 2;
    
        const carLeftSideTexture = getCarSideTexture();
        carLeftSideTexture.flipY = false;
    
        const carRightSideTexture = getCarSideTexture();
    
        const cabin = new THREE.Mesh(new THREE.BoxBufferGeometry(33, 24, 12), [
        new THREE.MeshLambertMaterial({ map: carFrontTexture }),
        new THREE.MeshLambertMaterial({ map: carBackTexture }),
        new THREE.MeshLambertMaterial({ map: carLeftSideTexture }),
        new THREE.MeshLambertMaterial({ map: carRightSideTexture }),
        new THREE.MeshLambertMaterial({ color: 0x080808 }), // top
        new THREE.MeshLambertMaterial({ color: 0x080808 }) // bottom
        ]);
        cabin.position.x = -6;
        cabin.position.z = 25.5;
        cabin.castShadow = true;
        cabin.receiveShadow = true;
        car.add(cabin);
    
        const backWheel = new Wheel();
        backWheel.position.x = -18;
        car.add(backWheel);
    
        const frontWheel = new Wheel();
        frontWheel.position.x = 18;
        car.add(frontWheel);
        car.position.set(pos[i].x,pos[i].y,pos[i].z);
        car.scale.set(scale.x,scale.y,scale.z);
        car.rotation.set(0,0.5,1);
        scene.add(car);

        //Ammojs Section
        let transform = new Ammo.btTransform();
        transform.setIdentity();
        transform.setOrigin( new Ammo.btVector3( pos[i].x +5, pos[i].y, pos[i].z +10 ) );
        transform.setRotation( new Ammo.btQuaternion( quat.x, quat.y, quat.z, quat.w ) );
        let motionState = new Ammo.btDefaultMotionState( transform );

        let colShape = new Ammo.btBoxShape( new Ammo.btVector3( scale.x * 15, scale.y * 10, scale.z * 10) );
        colShape.setMargin( 1 );

        let localInertia = new Ammo.btVector3( 0, 0, 0 );
        colShape.calculateLocalInertia( mass, localInertia );

        let rbInfo = new Ammo.btRigidBodyConstructionInfo( mass, motionState, colShape, localInertia );
        let body = new Ammo.btRigidBody( rbInfo );

        body.setFriction(4);
        body.setRollingFriction(10);


        physicsWorld.addRigidBody( body );
        car.userData.physicsBody = body;
        cars.push(car);
    }    
}

export{PauseButtonToggle,setupPhysicsWorld,setupGraphics,
    renderFrame,setupEventHandlers,handleKeyDown,
    handleKeyUp,updatePhysics,togglePause,createBackground,
    createSlippery,contactSlippery,createBlock,contactPlatform,
    createPlayer,jump,movePlayer,checkPlayerDead,createLives,
    contactHearts,createCoins,contactCoin,createSpikeyTotem,
    contactSpike, createAltPortal, contactPortal,createTree,
    createClouds,contactCar,setupContactPairResultCallback,
    createCar
}