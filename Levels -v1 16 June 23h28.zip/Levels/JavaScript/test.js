var h = document.createElement("H1"); // Create the H1 element 
h.style.textAlign = "center";
var t = document.createTextNode("GAME OVER"); // Create a text element 
h.appendChild(t); // Append the text node to the H1 element 

document.body.appendChild(h); // Append the H1 element to the document body
 


//create a button to reset
btnReset = document.createElement("BUTTON");
btnReset.innerHTML = "Restart";
btnReset.style.width = '100px'; // setting the width to 200px
btnReset.style.height = '50px'; // setting the height to 200px
btnReset.style.background = 'white'; // setting the background color to teal
btnReset.style.color = 'black'; // setting the color to white
btnReset.style.fontSize = '20px'; // setting the font size to 20px
btnReset.style.width = '50%';
// btnPause.style.background = "none";
// btnPause.style.border = "none";
document.body.appendChild(btnReset); 

btnReset.addEventListener("click", function() {
    //document.body.innerHTML = "Hello World";
    location.replace("index.html");
  }); 