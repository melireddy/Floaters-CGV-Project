import {PauseButtonToggle,setupPhysicsWorld,setupGraphics,
    renderFrame,setupEventHandlers,handleKeyDown,
    handleKeyUp,updatePhysics,togglePause,createBackground,
    createSlippery,contactSlippery,createBlock,contactPlatform,
    createPlayer,jump,movePlayer,checkPlayerDead,createLives,
    contactHearts,createCoins,contactCoin,createSpikeyTotem,
    contactSpike, createAltPortal, contactPortal,createTree,
    createClouds,contactCar,setupContactPairResultCallback,
    createCar} from './index.js';

// Getting html elements
const score = document.getElementById("score");
const menu = document.getElementById("mainMenu");
const fuel = document.getElementById("jumpFuel");
const levels = document.getElementById("levels");
const settings = document.getElementById("settings");
const credits = document.getElementById("credits");
const Playerlives = document.getElementById("lives");
const interface1 = document.getElementById("interface");
const PauseButton = document.getElementById("pauseButton");

// Show and hide html function
function hide(el) {
    el.style.display = 'none';
}
function show(el) {
    el.style.display = 'block';
} 

hide(interface1);
show(main);

document.querySelectorAll('.play')[0].addEventListener('click', function() {
    hide(main);
    show(interface1);
//Ammojs Initialization
Ammo().then(start)
});
document.querySelectorAll('.levels')[0].addEventListener('click', function() {
    hide(main);
    show(levels);
});
document.querySelectorAll('.settings')[0].addEventListener('click', function() {
    hide(main);
    show(settings);
});
document.querySelectorAll('.credits')[0].addEventListener('click', function() {
    hide(main);
    show(credits);
});
document.querySelectorAll('.back1')[0].addEventListener('click', function() {
    hide(levels);
    show(main);
});
document.querySelectorAll('.back2')[0].addEventListener('click', function() {
    hide(settings);
    show(main);
});
document.querySelectorAll('.back3')[0].addEventListener('click', function() {
    hide(credits);
    show(main);
});
document.querySelectorAll('.levelone')[0].addEventListener('click', function() {
    hide(levels);
    show(interface1);
    //Ammojs Initialization
    Ammo().then(start)
});
document.querySelectorAll('.pause')[0].addEventListener('click', function() {
    togglePause();
});

function start (){
    setupPhysicsWorld();
    setupGraphics();
    createBackground();
    createPlayer();
    var pos_platforms = [
        {x: 0, y: 0, z: 0},
        {x: 0, y: 0, z: -70},
        {x: 0, y: 0, z: -145},
        {x: 0, y: 0, z: -195},
        {x: 0, y: 0, z: -270}
    ];
    createBlock(pos_platforms,{x: 50, y: 2, z: 50});

    var pos_slippery = [
        {x: 0, y: 0, z:-380}
    ];
    createSlippery(pos_slippery,{x: 100, y: 2, z: 100});

    var pos_coin = [
        {x: 0, y: 5, z: -45},
        {x: 5, y: 5, z: -45},
        {x: 10, y: 5, z: -45},
        {x: 15, y: 5, z: -45},
        {x: 0, y: 5, z: -45},
        {x: -5, y: 5, z: -45},
        {x: -10, y: 5, z: -45},
        {x: -15, y: 5, z: -45},
        {x: 0, y: 5, z: -90},
        {x: 5, y: 5, z: -90},
        {x: 10, y: 5, z: -90},
        {x: 15, y: 5, z: -90},
        {x: 0, y: 5, z: -90},
        {x: -5, y: 5, z: -90},
        {x: -10, y: 5, z: -90},
        {x: -15, y: 5, z: -90},
        {x: 0, y: 5, z: -120},
        {x: 0, y: 15, z: -135},
        {x: 0, y: 5, z: -150},
        {x: 0, y: 5, z: -170},
        {x: 0, y: 15, z: -195},
        {x: 0, y: 5, z: -220},
        {x: 0, y: 5, z: -245},
        {x: -20, y: 5, z: -270},
        {x: 20, y: 5, z: -270},
        {x: 0, y: 5, z: -285},
        {x: 0, y: 5, z: -350},
        {x: 0, y: 10, z: -350},
        {x: 0, y: 15, z: -350},
        {x: 20, y: 5, z: -350},
        {x: 20, y: 10, z: -350},
        {x: 20, y: 15, z: -350},
        {x: -20, y: 5, z: -350},
        {x: -20, y: 10, z: -350},
        {x: -20, y: 15, z: -350}
    ];
    createCoins(pos_coin);


    var pos_totem = [
        {x: 0, y: 5, z: -60},
        {x: 10, y: 5, z: -60},
        {x: -10, y: 5, z: -60},
        {x: -20, y: 5, z: -60},
        {x: 20, y: 5, z: -60},
        {x: 0, y: 5, z: -70},
        {x: 10, y: 5, z: -70},
        {x: -10, y: 5, z: -70},
        {x: -20, y: 5, z: -70},
        {x: 20, y: 5, z: -70}
    ];
    createSpikeyTotem(pos_totem);

    var pos_cars = [
        {x: 0, y: 5, z: -140}
        // {x: 0, y: 5, z: -65},
        // {x: -5, y: 5, z: -88}
     ];
    createCar(pos_cars,{x: 0.5, y: 0.5, z: 0.5});
    setupContactPairResultCallback();
    setupEventHandlers();
    renderFrame();


}